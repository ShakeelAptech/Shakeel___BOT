(function () {
  let botActive = false; // بوٹ کی حالت (آن/آف)
  let tradeInProgress = false; // کیا ٹریڈ لگی ہوئی ہے؟
  let nextTradeTimeout = null; // اگلی ٹریڈ کے لیے ٹائمر

  // 1. نیا گول ایموجی پینل بنانا
  const panel = document.createElement("div");
  panel.id = "signal-panel";
  panel.style.cursor = "move"; 

  // تصویر کا یو آر ایل حاصل کریں (ہم نے اس کا نام 'bot.png' رکھا ہے)
  const imgUrl = chrome.runtime.getURL("bot.png");

  panel.innerHTML = `
    <img src="${imgUrl}" id="logo-img">
  `;
  document.body.appendChild(panel);

  // 2. پینل کو موو (Move) کرنے کا طریقہ
  let isDragging = false;
  let startX, startY;

  panel.addEventListener("mousedown", (e) => {
    isDragging = true;
    startX = e.clientX - panel.offsetLeft;
    startY = e.clientY - panel.offsetTop;
    e.preventDefault(); 
  });

  document.addEventListener("mousemove", (e) => {
    if (isDragging) {
      panel.style.left = (e.clientX - startX) + "px";
      panel.style.top = (e.clientY - startY) + "px";
      panel.style.transform = "none"; // موونگ کے دوران ٹرانسفارم ختم
    }
  });

  document.addEventListener("mouseup", () => {
    isDragging = false;
  });

  // موبائل ٹچ کے لیے موومنٹ
  panel.addEventListener("touchstart", (e) => {
    isDragging = true;
    let touch = e.touches[0];
    startX = touch.clientX - panel.offsetLeft;
    startY = touch.clientY - panel.offsetTop;
  });

  panel.addEventListener("touchmove", (e) => {
    if (isDragging) {
      let touch = e.touches[0];
      panel.style.left = touch.clientX - startX + "px";
      panel.style.top = touch.clientY - startY + "px";
      panel.style.transform = "none";
    }
  }, {passive: false});

  panel.addEventListener("touchend", () => {
    isDragging = false;
  });

  // 3. ٹریڈ لاجک (ایموجی پر کلک سے آن/آف)
  
  // ایموجی پر کلک کرنے سے بوٹ آن/آف ہوگا
  panel.addEventListener("click", (e) => {
    // اگر ہم موو کر رہے ہیں تو کلک رجسٹر نہ ہو
    if (e.defaultPrevented) return; 

    botActive = !botActive;
    panel.classList.toggle("bot-active", botActive); // آن ہونے پر ہلکا گرین بارڈر کے لیے

    if (botActive) {
      console.log("QUOTEX AI STARTED");
      executeProcess(); // آن ہوتے ہی پہلی ٹریڈ کی کوشش کرے
    } else {
      console.log("QUOTEX AI STOPPED");
      clearTimeout(nextTradeTimeout); // اگر ٹائمر چل رہا ہو تو اسے ختم کریں
      tradeInProgress = false; // ٹریڈ کا سٹیٹس ری سیٹ کریں
    }
  });

  async function executeProcess() {
    // اگر بوٹ آف ہو یا پہلے ہی ٹریڈ چل رہی ہو، تو باہر نکل جائیں
    if (!botActive || tradeInProgress) return;
    
    tradeInProgress = true;
    
    // براہ راست ٹریڈ کی کوشش (کوئی اسکیننگ نہیں)
    
    const buttons = Array.from(document.querySelectorAll('button'));
    const up = buttons.find(b => b.innerText.includes('Up') || b.classList.contains('btn-call'));
    const down = buttons.find(b => b.innerText.includes('Down') || b.classList.contains('btn-put'));

    if (up && down) {
      // رینڈم ٹریڈ لینا (Up یا Down)
      const isBuy = Math.random() > 0.5;
      (isBuy ? up : down).click();
      console.log(`TRADE PLACED: ${isBuy ? 'UP' : 'DOWN'}`);
      
      // آپ کی شرط: 30 سیکنڈ کا وقفہ
      // ہم فرض کر رہے ہیں کہ ٹریڈ فوراً ایکزیٹ (Exit) ہو گئی ہے
      nextTradeTimeout = setTimeout(() => {
        tradeInProgress = false; // 30 سیکنڈ بعد ٹریڈ سٹیٹس ری سیٹ کریں
        if (botActive) executeProcess(); // اگر بوٹ ابھی بھی آن ہے تو اگلی ٹریڈ لیں
      }, 30000); // 30000 ملی سیکنڈ = 30 سیکنڈ

    } else {
      console.log("BUTTON ERROR: Could not find Up/Down buttons");
      tradeInProgress = false;
      // اگر بٹن نہ ملیں تو 5 سیکنڈ بعد دوبارہ کوشش کریں
      if (botActive) nextTradeTimeout = setTimeout(executeProcess, 5000);
    }
  }
})();
