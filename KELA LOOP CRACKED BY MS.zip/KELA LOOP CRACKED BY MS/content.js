(function () {
  let botActive = false;
  let tradeInProgress = false;
  let nextTradeTimeout = null;

  // 1. Main Container
  const botContainer = document.createElement("div");
  botContainer.id = "banana-bot-container";
  document.body.appendChild(botContainer);

  // 2. Small Banana Logo
  const logoWrapper = document.createElement("div");
  logoWrapper.id = "banana-logo-wrapper";
  logoWrapper.innerHTML = `<img src="${chrome.runtime.getURL("logo.png")}" id="banana-logo-img">`;
  botContainer.appendChild(logoWrapper);

  // 3. Large Rectangle Panel
  const infoPanel = document.createElement("div");
  infoPanel.id = "banana-info-panel";
  infoPanel.innerHTML = `
    <div id="banana-header">Trading Bot</div>
    <div class="status-wrapper">
        Status: <span id="bot-status-text" class="status-off">OFF</span>
    </div>
    <button id="banana-control-btn">START</button>
  `;
  botContainer.appendChild(infoPanel);

  const statusText = document.getElementById("bot-status-text");
  const controlBtn = document.getElementById("banana-control-btn");

  // Toggle Panel on Logo Click
  logoWrapper.addEventListener("click", () => {
    infoPanel.classList.toggle("show-panel");
  });

  // Start/Stop Button Logic
  controlBtn.addEventListener("click", () => {
    botActive = !botActive;
    if (botActive) {
      statusText.innerText = "ON";
      statusText.className = "status-on";
      controlBtn.innerText = "STOP";
      controlBtn.classList.add("btn-stop");
      executeProcess();
    } else {
      statusText.innerText = "OFF";
      statusText.className = "status-off";
      controlBtn.innerText = "START";
      controlBtn.classList.remove("btn-stop");
      clearTimeout(nextTradeTimeout);
      tradeInProgress = false;
    }
  });

  async function executeProcess() {
    if (!botActive || tradeInProgress) return;
    tradeInProgress = true;
    
    const buttons = Array.from(document.querySelectorAll('button'));
    const up = buttons.find(b => b.innerText.includes('Up') || b.classList.contains('btn-call'));
    const down = buttons.find(b => b.innerText.includes('Down') || b.classList.contains('btn-put'));

    if (up && down) {
      const isBuy = Math.random() > 0.5;
      (isBuy ? up : down).click();

      // 30 seconds delay before next trade, but UI stays "ON"
      nextTradeTimeout = setTimeout(() => {
        tradeInProgress = false;
        if (botActive) executeProcess();
      }, 30000); 
    } else {
      tradeInProgress = false;
      if (botActive) nextTradeTimeout = setTimeout(executeProcess, 5000);
    }
  }
})();
